import function

array = function.getArray()
summ = function.addAll(array)
print(summ/len(array))