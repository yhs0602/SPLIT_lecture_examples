import os

folder = input("폴더 경로를 입력하세요:")

print(os.listdir(folder))
