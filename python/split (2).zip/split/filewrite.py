outfile = open("out.txt",mode = "a")
outfile.write("새로운 파일 내용")
outfile.close()
