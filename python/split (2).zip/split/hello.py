import math

#root4 = math.sqrt(4)

num1 = float(input("숫자를 입력하세요"))
num2 = float(input("숫자를 입력하세요"))

print("답은" + str(num1+num2))