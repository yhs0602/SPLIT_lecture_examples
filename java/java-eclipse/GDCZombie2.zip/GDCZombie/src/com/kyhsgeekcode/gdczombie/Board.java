package com.kyhsgeekcode.gdczombie;

public class Board {
	Unit unit;
	public boolean hasUnit()
	{
		return this.unit != null;
	}
	public void SetUnit(Unit unit)
	{
		this.unit = unit;
	}
	public void Bye()
	{
		unit = null;
	}
	
	public boolean hasBaricade[] = new boolean[4];
	public Unit getUnit() {
		// TODO Auto-generated method stub
		return unit;
	}
}
