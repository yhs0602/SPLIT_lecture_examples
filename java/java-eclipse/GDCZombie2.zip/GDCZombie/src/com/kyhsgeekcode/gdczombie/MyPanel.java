package com.kyhsgeekcode.gdczombie;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.JPanel;

public class MyPanel extends JPanel {
	public MyPanel() {
        setBorder(BorderFactory.createLineBorder(Color.black));
        try {
			imgZombie = ImageIO.read(new File("zombie.png"));
			imgCivilian = ImageIO.read(new File("civilian.png"));
			imgParty = ImageIO.read(new File("party.png"));
			imgEmpty = ImageIO.read(new File("empty.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    public Dimension getPreferredSize() {
        return new Dimension(480,480);
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        for(int i=0; i<Main.boards.length; i++ )
        {
        	for(int j=0; j<Main.boards.length; j++ )
        	{
        		int x = i * ImgSizeX;
        		int y = j * ImgSizeY;
        		Unit u = Main.boards[i][j].getUnit();
        		Image img = imgEmpty;
        		if(u != null)
        		{
        			if(u instanceof Civilian)
        			{
        				img = imgCivilian;
        			} else if (u instanceof Zombie)
        			{
        				img = imgZombie;
        			} else if (u instanceof Party)
        			{
        				img = imgParty;
        			}
        		}
        		g.drawImage(img, x, y, ImgSizeX, ImgSizeY, null);
                
        	}
        }
        // Draw Text
        //g.drawString("This is my custom Panel!",10,20);
    }  
    Image imgZombie;
    Image imgCivilian;
    Image imgParty;
    Image imgEmpty;
    public static final int ImgSizeX = 30;
    public static final int ImgSizeY = 30;
    
}
