package com.kyhsgeekcode.gdczombie;

public enum Orientation {
	east,
	west,
	south,
	north;
}
