package com.kyhsgeekcode.gdczombie;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		PrepareBoard();
		SpawnParties();
		SpawnCivilians();
		SpawnZombies();
		PrintCircumstance();
		//CreateEventCards();
		while(true)
		{
			ApplyEventCard();
			GetInput();
			MoveCivilians();
			if(MoveZombies())
			{
				break;
			}
			PrintCircumstance();
		}
		
	}
	
	static final int BOARDSIZEX = 16;
	static final int BOARDSIZEY = 16;
	
	static Board [][] boards = new Board[BOARDSIZEX][BOARDSIZEY];

	static void PrepareBoard()
	{
		for(int i=0;i<boards.length;i++)
		{
			for(int j=0;j<boards[0].length;j++)
			{
				boards[i][j] = new Board();
			}
		}
	}
	static void SpawnParties()
	{
		for(int i=0; i<4; i++)
		{
			int x = random.nextInt(boards.length-1);
			int y = random.nextInt(boards[0].length-1);
			if(!boards[x][y].hasUnit())
				boards[x][y].SetUnit(new Party(x, y));
			else
				i--;
		}
	}
	
	static void SpawnCivilians()
	{
		for(int i=0; i<4; i++)
		{
			int x = random.nextInt(boards.length-1);
			int y = random.nextInt(boards[0].length-1);
			if(!boards[x][y].hasUnit())
				boards[x][y].SetUnit(new Civilian(x, y));
			else
				i--;
		}
	}
	static void SpawnZombies()
	{
		for(int i=0; i<4; i++)
		{
			int x = random.nextInt(boards.length-1);
			int y = random.nextInt(boards[0].length-1);
			if(!boards[x][y].hasUnit())
				boards[x][y].SetUnit(new Zombie(x, y));
			else
				i--;
		}
	}
	
	static void ApplyEventCard()
	{
		Field[] cards =  EventCard.class.getDeclaredFields();
		ArrayList<EventCard> ecards = new ArrayList<EventCard>();
		for(Field card: cards)
		{
			if(card.getType().equals(EventCard.class))
			{
				try {
					ecards.add((EventCard)card.get(null));
				} catch (IllegalArgumentException | IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		ecards.get(random.nextInt(ecards.size()-1)).Apply();
	}
	
	static void MoveCivilians()
	{
		for(Civilian c: civilians)
		{
			c.move();
		}
	}
	
	static boolean MoveZombies()
	{
		ArrayList<Zombie> az = new ArrayList<>();
		az.addAll(zombies);
		for(Zombie z: az)
		{
			z.move();
		}
		return civilians.isEmpty() && parties.isEmpty();
	}
	
	static void GetInput()
	{
		Scanner sc = new Scanner(System.in);
		while(true)
		{
			String command = sc.next();
			command = command.toLowerCase();
			if(command.compareTo("end")==0)
			{
				return;
			} else if (command.equals( "move")) {
				int from = sc.nextInt();
				//int to = sc.nextInt();
				int fx = from / Main.BOARDSIZEX;
				int fy = from % Main.BOARDSIZEX;
				//int tx = to % Main.BOARDSIZEX;
				//int ty = to / Main.BOARDSIZEX;
				String ori = sc.next();
				Orientation orie = Orientation.valueOf(ori);
				int dx=0, dy=0;
				switch(orie)
				{
				case east:
					dx = 1;
					dy = 0;
					break;
				case west:
					dx = -1;
					dy = 0;
					break;
				case south:
					dx = 0;
					dy = 1;
					break;
				case north:
					dx = 0;
					dy = -1;
					break;
				}
				
				boards[fx][fy].getUnit().moveTo(fx + dx,fy + dy);
		//		int fx = getX(from);
		//		int fy = getY(from);
		//		int tx = getX(from);
		///		int ty = getY(from);
			} else if (command.equals( "bar"))
			{
				int from = sc.nextInt();
				int fx = from / Main.BOARDSIZEX;
				int fy = from % Main.BOARDSIZEX;
				String ori = sc.next();
				Orientation orie = Orientation.valueOf(ori);
				Main.boards[fx][fy].hasBaricade[orie.ordinal()]= true;
			}
			
		}
	}
	
	
	static void PrintCircumstance()
	{
		for(int i=0; i< boards.length; i++)
		{
			for(int j = 0; j < boards[0].length; j++)
			{
				System.out.print(getCharacter(boards[i][j]));
			}
			System.out.println();
		}
	}
	static String getCharacter(Board b)
	{
		if(b.hasUnit())
		{
			Unit u = b.getUnit();
			if(u instanceof Zombie)
			{
				return "��";
			} if(u instanceof Civilian)
			{
				return "��";
			} if(u instanceof Party)
			{
				return "��";
			}
		}
		return "��";
	}
	/*
	static int getX(String s)
	{
		char [] cs = s.toCharArray();
		int i=0;
		String alphabet = "";
		while(i < cs. length && Character.isAlphabetic(cs[i]))
		{
			alphabet += cs[i];
		}
		
	}
	*/
	//static void CreateEventCards()
	//{
	//	
	//}
	static Random random = new Random();
	static ArrayList<Civilian> civilians = new ArrayList<>();
	static ArrayList<Zombie> zombies = new ArrayList<>();
	static ArrayList<Party> parties = new ArrayList<>();
	
}
